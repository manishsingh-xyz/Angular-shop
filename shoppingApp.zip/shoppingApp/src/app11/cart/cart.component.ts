import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  CartDetail: any;
  isEmpty: boolean;
  isDeleted: boolean;

  constructor(
    private location: Location
  ) { }

  ngOnInit() {
    this.isEmpty = false;
    this.checkCart();
    this.isDeleted = false;  
  }

  checkCart(): void {
    this.CartDetail = JSON.parse(localStorage.getItem('CartItem'));
    console.log(this.CartDetail);
    if(this.CartDetail !== null){
      this.isEmpty = false;
    }
    else{
      this.isEmpty = true;
    }
  }

  reduceQuantity(data): void {
    var checkCart = JSON.parse(localStorage.getItem('CartItem'));
    for(let i=0; i < checkCart.length; i++){
      if(data.id === checkCart[i].id){
        localStorage.removeItem('CartItem');
        checkCart[i].quantity = checkCart[i].quantity - 1;
        this.CartDetail = checkCart;
        localStorage.setItem('CartItem', JSON.stringify(this.CartDetail));    
      }
    }
  }

  increaseQuantity(data): void {
    var checkCart = JSON.parse(localStorage.getItem('CartItem'));
    for(let i=0; i < checkCart.length; i++){
      if(data.id === checkCart[i].id){
        localStorage.removeItem('CartItem');
        checkCart[i].quantity = checkCart[i].quantity + 1;
        this.CartDetail = checkCart;
        localStorage.setItem('CartItem', JSON.stringify(this.CartDetail));    
      }
    }
  }

  deleteItem(num): void {
    localStorage.removeItem('CartItem');
    (this.CartDetail).splice(num, 1);
    localStorage.setItem('CartItem', JSON.stringify(this.CartDetail));
    if(this.CartDetail.length == 0){
      this.isDeleted = true;
      this.CartDetail = null;
      this.isEmpty = true;
      localStorage.removeItem('CartItem');
    }    
  }

  emptyCart(): void {
    localStorage.removeItem('CartItem');
    this.isDeleted = true;
    this.CartDetail = null;
    this.isEmpty = true;
  }

  goBack(): void {
    this.location.back();
  }
}
