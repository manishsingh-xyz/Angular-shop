export class Product {
    id: string;
    image: string;
    product: string;
    code: string;
    available: string;
    price: string;
    starRating: string;
    category: string;
    quantity: number;
}
