import { Component, OnInit, Input } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ProductserviceService } from '../productservice.service';


import {BrowserModule, Title} from '@angular/platform-browser';
import {Headers, Response} from '@angular/http';
import { Product } from '../product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  titles: Array<any>;
  products: Array<any>;
  totalRec: number;
  page: number = 1;
  listFilter= 'cart';
  showImage: boolean=false;
  model: any={};
  model2: any={};
  msg: any= " ";
  amount: number;
  isCartEmpty: boolean;
  sign: string;
  filterStatus = '';
  fieldName = '';

  constructor(private _productService: ProductserviceService){
  }

  productdata: Product[];
  ngOnInit() {
    this.getProducts();
  }

  getProducts(): void {
    this._productService.getProducts()
    .subscribe(productdata => this.productdata = productdata);
  }

}
