import { Product } from './product';

export const PRODUCTS: Product[] = [
    {
        "id": "1",
        "image": "men polo tshirt2.jpg",
        "product": "Tommy Hilfiger Polo Tshirt",
        "code": "T116",
        "available": "yes",
        "price": "2500",
        "starRating": "5",
        "category": "men",
        "quantity":0
      },
      {
        "id": "2",
        "image": "men shirt1.jpg",
        "product": "Tommy Hilfiger Shirt",
        "code": "T117",
        "available": "yes",
        "price": "2500",
        "starRating": "4",
        "category": "men",
        "quantity":0
      },
      {
        "id": "3",
        "image": "men shirt2.jpg",
        "product": "Tommy Hilfiger Shirt",
        "code": "T118",
        "available": "No",
        "price": "3000",
        "starRating": "3",
        "category": "men",
        "quantity":0
      },
      {
        "id": "4",
        "image": "men shirt3.jpg",
        "product": "Tommy Hilfiger Shirt",
        "code": "T119",
        "available": "yes",
        "price": "4000",
        "starRating": "5",
        "category": "men",
        "quantity":0
      },
      {
        "id": "11",
        "image": "shoe2.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T126",
        "available": "yes",
        "price": "3000",
        "starRating": "3",
        "category": "men",
        "quantity":0
      },
      {
        "id": "12",
        "image": "shoe3.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T127",
        "available": "yes",
        "price": "3000",
        "starRating": "3",
        "category": "men",
        "quantity":0
      },
      {
        "id": "14",
        "image": "shoe5.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T129",
        "available": "yes",
        "price": "4000",
        "starRating": "5",
        "category": "men",
        "quantity":0
      },
      {
        "id": "15",
        "image": "shoe6.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T130",
        "available": "yes",
        "price": "3500",
        "starRating": "4",
        "category": "men",
        "quantity":0
      },
      {
        "id": "17",
        "image": "wallet2.jpg",
        "product": "Tommy Hilfiger Wallet",
        "code": "T132",
        "available": "yes",
        "price": "3000",
        "starRating": "4",
        "category": "men",
        "quantity":0
      },
      {
        "id": "19",
        "image": "wallet4.jpg",
        "product": "Tommy Hilfiger Wallet",
        "code": "T134",
        "available": "yes",
        "price": "4000",
        "starRating": "3",
        "category": "men",
        "quantity":0
      },
      {
        "id": "5",
        "image": "women1.jpg",
        "product": "Tommy Hilfiger Women Top",
        "code": "T120",
        "available": "yes",
        "price": "1500",
        "starRating": "4",
        "category": "women",
        "quantity":0
      },
      {
        "id": "6",
        "image": "women2.jpg",
        "product": "Tommy Hilfiger Women Dress",
        "code": "T121",
        "available": "yes",
        "price": "5000",
        "starRating": "4",
        "category": "women",
        "quantity":0
      },
      {
        "id": "7",
        "image": "women3.jpg",
        "product": "Tommy Hilfiger Women Top",
        "code": "T122",
        "available": "yes",
        "price": "1800",
        "starRating": "3",
        "category": "women",
        "quantity":0
      },
      {
        "id": "8",
        "image": "women4.jpg",
        "product": "Tommy Hilfiger Women Top",
        "code": "T123",
        "available": "yes",
        "price": "3000",
        "starRating": "3",
        "category": "women",
        "quantity":0
      },
      {
        "id": "9",
        "image": "women5.jpg",
        "product": "Tommy Hilfiger Women Top",
        "code": "T124",
        "available": "No",
        "price": "2000",
        "starRating": "2",
        "category": "women",
        "quantity":0
      },
      {
        "id": "10",
        "image": "shoe1.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T125",
        "available": "yes",
        "price": "3000",
        "starRating": "3",
        "category": "women",
        "quantity":0
      },
      {
        "id": "13",
        "image": "shoe4.jpg",
        "product": "Tommy Hilfiger Shoe",
        "code": "T128",
        "available": "yes",
        "price": "5000",
        "starRating": "3",
        "category": "women",
        "quantity":0
      },
      {
        "id": "16",
        "image": "wallet1.jpg",
        "product": "Tommy Hilfiger Wallet",
        "code": "T131",
        "available": "yes",
        "price": "3000",
        "starRating": "3",
        "category": "women",
        "quantity":0
      },
      {
        "id": "18",
        "image": "wallet3.jpg",
        "product": "Tommy Hilfiger Wallet",
        "code": "T133",
        "available": "yes",
        "price": "2900",
        "starRating": "4",
        "category": "women",
        "quantity":0
      },
      {
        "id": "20",
        "image": "wallet5.jpg",
        "product": "Tommy Hilfiger Wallet",
        "code": "T135",
        "available": "yes",
        "price": "3800",
        "starRating": "4.5",
        "category": "women",
        "quantity":0
      },
      {
        "id": "21",
        "image": "handbag1.jpg",
        "product": "Tommy Hilfiger Handbag",
        "code": "T136",
        "available": "yes",
        "price": "5500",
        "starRating": "5",
        "category": "women",
        "quantity":0
      },
      {
        "id": "22",
        "image": "handbag2.jpg",
        "product": "Tommy Hilfiger Handbag",
        "code": "T137",
        "available": "yes",
        "price": "5000",
        "starRating": "4",
        "category": "women",
        "quantity":0
      },
      {
        "id": "23",
        "image": "handbag3.jpg",
        "product": "Tommy Hilfiger Handbag",
        "code": "T138",
        "available": "yes",
        "price": "6400",
        "starRating": "5",
        "category": "women",
        "quantity":0
      }
];