import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { ProductserviceService } from './productservice.service';
import {NgxPaginationModule} from 'ngx-pagination';
import { Http } from '@angular/http';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { AppRoutingModule } from './/app-routing.module';
import { CartComponent } from './cart/cart.component';
import { CartUpdationService } from './cart-updation.service';
import { FilterPipe } from './filter.pipe';
import { SortPipe } from './sort.pipe';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductsComponent,
    ProductdetailsComponent,
    CartComponent,
    FilterPipe,
    SortPipe
  ],
  imports: [
    BrowserModule, HttpClientModule, NgxPaginationModule,
    HttpModule, FormsModule, CarouselModule.forRoot(), AppRoutingModule
  ],
  providers: [ProductserviceService, CartUpdationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
