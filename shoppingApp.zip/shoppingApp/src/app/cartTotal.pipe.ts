import { Pipe } from '@angular/core';

@Pipe({name: 'cartTotal'})
export class TotalPipe {
    transform(value) {
        let total = 0;
        if (value) {
            value.forEach(Cart => {
                total += Cart.price*Cart.quantity;
            });
        }
        return total;
    }
}