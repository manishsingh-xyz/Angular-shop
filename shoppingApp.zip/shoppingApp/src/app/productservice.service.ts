import {BrowserModule} from '@angular/platform-browser';
import {Injectable} from '@angular/core';
import {Http, Response, RequestOptions,Headers} from '@angular/http';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { Observable, } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Product } from './product';
import { PRODUCTS } from './mock_products';

@Injectable()
export class ProductserviceService {

  constructor(private _http:Http){}



    getJson(): any {
        return this._http.get("/assets/titles.json")
        .map(res=>res.json())
    }

    getSpecificProduct(): any {
        return this._http.get("/assets/titles.json")
        .map(res=>res.json())
    }


    getProducts(): Observable<Product[]> {
      return of(PRODUCTS);
    }

    getProduct(id: string): Observable<Product> {
      return of(PRODUCTS.find(product => product.id === id));
    }

}
