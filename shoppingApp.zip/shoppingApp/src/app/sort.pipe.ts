import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {
  transform(records: Array<any>, args?: any): any {
    const check = args.startsWith('-');
    const arr = args.split('-');
    const elem = arr[1];
    return records.sort(function(a, b){
        if (a[elem] < b[elem] && check) {
          return -1 * -1;
        }else if ( a[elem] > b[elem] && check) {
          return 1 * -1;
        }else if (a[args] < b[args] && !check) {
          return -1;
        }else if (a[args] > b[args] && !check) {
          return 1;
        }else {
            return 0;
        }
    });
}
}
