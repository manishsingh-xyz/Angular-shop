import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ProductserviceService } from '../productservice.service';
import { Product } from '../product';
import { CartUpdationService } from '../cart-updation.service';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {
  @Input() product: Product;

  dataAdded: boolean;
  cartItems: Product[] = [];

  constructor(
    private route: ActivatedRoute,
    private productService: ProductserviceService,
    private cartUpdateService: CartUpdationService,
    private location: Location,
  ) { }

  ngOnInit() {
    this.getProduct();
    this.dataAdded = false;
  }

  getProduct(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.productService.getProduct(id)
      .subscribe(product => this.product = product);
  }

  goBack(): void {
    this.location.back();
  }

  addToCart(data): void {
    this.cartUpdateService.addToCart(data);
    this.dataAdded = true;
  }
}
