import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable()
export class CartUpdationService {
  cartItems: Array<any> = [];


  constructor() { }

  addToCart(data) {
    var checkCart = JSON.parse(localStorage.getItem('CartItem'));
    console.log(checkCart);
    var datamatch = false;
    if(checkCart !== null) {
      for(let i = 0; i < checkCart.length; i++){
        if(data.id === checkCart[i].id) {
          localStorage.removeItem('CartItem');
          checkCart[i].quantity = checkCart[i].quantity + 1;
          this.cartItems = checkCart;
          datamatch = true;
        } else {
          this.cartItems = checkCart;
        }
      }
      if(datamatch === false){
        data.quantity = 1;
        this.cartItems.push(data);
      }
    }
    else{
      data.quantity = 1;
      this.cartItems.push(data);
    }
    localStorage.setItem('CartItem', JSON.stringify(this.cartItems));    
  }
}
