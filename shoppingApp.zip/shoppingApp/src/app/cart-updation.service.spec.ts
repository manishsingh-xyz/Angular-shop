import { TestBed, inject } from '@angular/core/testing';

import { CartUpdationService } from './cart-updation.service';

describe('CartUpdationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CartUpdationService]
    });
  });

  it('should be created', inject([CartUpdationService], (service: CartUpdationService) => {
    expect(service).toBeTruthy();
  }));
});
